1. Reboot your Mac and hold the CMD + R keys
2. When presented with the recovery options, click Utilities at the top and choose Terminal
3. Type: csrutil disable
4. Reboot as normal
5. copy ftp and telnet binaries in /usr/bin folder
6. in a terminal type: sudo chmod +xr /usr/bin/telnet
7. in a terminal type: sudo chmod +xr /usr/bin/ftp
8. Reboot your Mac and hold the CMD + R keys
9. When presented with the recovery options, click Utilities at the top and choose Terminal
10. Type: csrutil enable
11. Reboot as normal
